import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from header_sorter import (  # noqa: E402
    Header,
    InvalidHeaderError,
    canonical_name,
    canonical_value,
    check_header,
    parse_headers,
    sort_headers,
)


class CanonicalNameTests(unittest.TestCase):
    def test_lowercases(self):
        self.assertEqual(canonical_name("Accept"), "accept")
        self.assertEqual(canonical_name("X-Request-ID"), "x-request-id")

    def test_tchar_set_allowed(self):
        self.assertEqual(canonical_name("a!#$%&'*+-.^_`|~09Z"), "a!#$%&'*+-.^_`|~09z")

    def test_rejects_whitespace_colon_and_empty(self):
        for name in ("", " ", "Accept ", "Bad Name", ":path", "a:b", "a\tb"):
            with self.subTest(name=name):
                with self.assertRaises(InvalidHeaderError) as ctx:
                    canonical_name(name)
                self.assertEqual(ctx.exception.code, "header.name-invalid")

    def test_rejects_non_ascii(self):
        with self.assertRaises(InvalidHeaderError):
            canonical_name("naïve")

    def test_rejects_non_string(self):
        with self.assertRaises(InvalidHeaderError) as ctx:
            canonical_name(None)
        self.assertEqual(ctx.exception.code, "header.name-invalid")


class CanonicalValueTests(unittest.TestCase):
    def test_trims_leading_and_trailing_ows(self):
        self.assertEqual(canonical_value("  a  "), "a")
        self.assertEqual(canonical_value("\t a \t"), "a")
        self.assertEqual(canonical_value(""), "")

    def test_preserves_internal_whitespace(self):
        self.assertEqual(canonical_value("a   b"), "a   b")
        self.assertEqual(canonical_value("a\tb"), "a\tb")

    def test_allows_non_ascii(self):
        self.assertEqual(canonical_value("café"), "café")

    def test_rejects_control_characters(self):
        for value in ("a\rb", "a\nb", "a\x00b", "a\x7fb", "a\x1fb"):
            with self.subTest(value=value):
                with self.assertRaises(InvalidHeaderError) as ctx:
                    canonical_value(value)
                self.assertEqual(ctx.exception.code, "header.value-control-char")

    def test_allows_tab(self):
        self.assertEqual(canonical_value("a\tb"), "a\tb")

    def test_rejects_non_string(self):
        with self.assertRaises(InvalidHeaderError) as ctx:
            canonical_value(3)
        self.assertEqual(ctx.exception.code, "header.value-type")


class CheckHeaderTests(unittest.TestCase):
    def test_returns_canonical_header(self):
        self.assertEqual(check_header("Accept", " */* "), Header("accept", "*/*"))


class StrictParseTests(unittest.TestCase):
    def test_control_character_rejected(self):
        with self.assertRaises(InvalidHeaderError):
            parse_headers("x: a\nb", strict=True)

    def test_control_character_in_folded_line_rejected(self):
        with self.assertRaises(InvalidHeaderError):
            parse_headers("x: a\n  b\x00c", strict=True)

    def test_trimming_stays_silent(self):
        self.assertEqual(
            parse_headers("Host :   example.com  ", strict=True),
            (Header("Host", "example.com"),),
        )

    def test_strict_keeps_order_and_names(self):
        self.assertEqual(
            parse_headers("B: 2\nA:  1", strict=True),
            (Header("B", "2"), Header("A", "1")),
        )

    def test_strict_does_not_add_comment_support(self):
        with self.assertRaises(InvalidHeaderError):
            parse_headers("# comment\nA: 1", strict=True)

    def test_sort_unchanged_without_strict(self):
        self.assertEqual(sort_headers("B: 2\nA:  1"), "A: 1\nB: 2")


class ErrorAttributeTests(unittest.TestCase):
    def test_defaults(self):
        error = InvalidHeaderError("boom")
        self.assertEqual(error.code, "header.syntax")
        self.assertEqual(error.location, "")
        self.assertTrue(isinstance(error, ValueError))
        self.assertEqual(str(error), "boom")

    def test_line_number_preserved(self):
        with self.assertRaises(InvalidHeaderError) as ctx:
            parse_headers("Host: example.com\nnot a header")
        self.assertIn("line 2", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
