import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from header_sorter import (  # noqa: E402
    Header,
    InvalidHeaderError,
    parse_headers,
    sort_headers,
)


class ParseHeaderTests(unittest.TestCase):
    def test_parses_pairs_in_order(self):
        headers = parse_headers("Host: example.com\nAccept: */*")
        self.assertEqual(
            headers,
            (Header("Host", "example.com"), Header("Accept", "*/*")),
        )

    def test_blank_lines_and_padding_ignored(self):
        headers = parse_headers("\n\n  Host :   example.com  \n\n")
        self.assertEqual(headers, (Header("Host", "example.com"),))

    def test_value_may_be_empty(self):
        self.assertEqual(parse_headers("X-Empty:"), (Header("X-Empty", ""),))

    def test_value_may_contain_colons(self):
        headers = parse_headers("Referer: https://example.com/a?b=c")
        self.assertEqual(headers[0].value, "https://example.com/a?b=c")

    def test_folded_lines_are_joined(self):
        headers = parse_headers("Accept: text/html\n  , text/plain\nX-Next: 1")
        self.assertEqual(
            headers,
            (Header("Accept", "text/html , text/plain"), Header("X-Next", "1")),
        )

    def test_crlf_and_cr_line_endings(self):
        for sep in ("\r\n", "\r"):
            with self.subTest(sep=sep):
                headers = parse_headers(f"B: 2{sep}A: 1")
                self.assertEqual((headers[0].name, headers[1].name), ("B", "A"))

    def test_missing_colon_rejects_with_line_number(self):
        with self.assertRaises(InvalidHeaderError) as ctx:
            parse_headers("Host: example.com\nnot a header")
        self.assertIn("line 2", str(ctx.exception))

    def test_empty_name_rejected(self):
        with self.assertRaises(InvalidHeaderError):
            parse_headers(": value")

    def test_invalid_name_token_rejected(self):
        with self.assertRaises(InvalidHeaderError):
            parse_headers('Bad Name: value')
        with self.assertRaises(InvalidHeaderError):
            parse_headers('Bad"Name: value')

    def test_orphaned_continuation_rejected(self):
        with self.assertRaises(InvalidHeaderError):
            parse_headers("  indented first")

    def test_empty_input_rejected(self):
        with self.assertRaises(InvalidHeaderError):
            parse_headers("   \n\n")

    def test_non_string_input_rejected(self):
        with self.assertRaises(InvalidHeaderError):
            parse_headers(None)

    def test_error_is_value_error(self):
        self.assertTrue(issubclass(InvalidHeaderError, ValueError))


class DowncaseTests(unittest.TestCase):
    def test_names_are_lowercased(self):
        text = "Host: example.com\nX-Request-ID: 7f1c2d\naccept: */*"
        self.assertEqual(
            sort_headers(text, downcase=True),
            "accept: */*\nhost: example.com\nx-request-id: 7f1c2d",
        )

    def test_values_keep_their_case(self):
        text = "Authorization: Bearer AbC123\nCookie: Session=XYZ"
        self.assertEqual(
            sort_headers(text, downcase=True),
            "authorization: Bearer AbC123\ncookie: Session=XYZ",
        )

    def test_case_is_preserved_by_default(self):
        self.assertEqual(
            sort_headers("Host: example.com"), "Host: example.com"
        )

    def test_parse_headers_downcases_names(self):
        headers = parse_headers("Content-Type: text/html", downcase=True)
        self.assertEqual(headers, (Header("content-type", "text/html"),))

    def test_folded_continuation_inherits_lowercase_name(self):
        headers = parse_headers("X-Note: a\n  b", downcase=True)
        self.assertEqual(headers, (Header("x-note", "a b"),))

    def test_downcase_keeps_duplicates_in_order(self):
        self.assertEqual(
            sort_headers("Set-Cookie: b\nset-cookie: a", downcase=True),
            "set-cookie: b\nset-cookie: a",
        )


class SortHeaderTests(unittest.TestCase):
    def test_sorted_alphabetically_case_insensitive(self):
        text = "x-trace: 1\nHost: example.com\naccept: */*\nCookie: a=b"
        self.assertEqual(
            sort_headers(text),
            "accept: */*\nCookie: a=b\nHost: example.com\nx-trace: 1",
        )

    def test_output_is_normalised(self):
        self.assertEqual(sort_headers("  Host:example.com\n\n"), "Host: example.com")

    def test_duplicates_keep_relative_order(self):
        self.assertEqual(
            sort_headers("Set-Cookie: b\nSet-Cookie: a"),
            "Set-Cookie: b\nSet-Cookie: a",
        )

    def test_sort_is_case_insensitive_with_pasted_order_as_tiebreak(self):
        text = "banana: 1\nApple: 2\ncarrot: 3\napple: 4"
        self.assertEqual(
            sort_headers(text),
            "Apple: 2\napple: 4\nbanana: 1\ncarrot: 3",
        )
        self.assertEqual(
            sort_headers(text, downcase=True),
            "apple: 2\napple: 4\nbanana: 1\ncarrot: 3",
        )

    def test_str_of_header(self):
        self.assertEqual(str(Header("Host", "example.com")), "Host: example.com")


if __name__ == "__main__":
    unittest.main()
