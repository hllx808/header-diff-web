# header-sorter

Take multi-line request-header text in, get clean alphabetical headers out.
No dependencies, standard library only.

## Install

```bash
pip install ./python-packages/header-sorter   # from the repository root
```

Or for local development:

```bash
pip install -e ./python-packages/header-sorter
```

## Use

```python
from header_sorter import sort_headers

text = """
Host: example.com
accept:   application/json
  , text/plain
X-Trace-Id:abc123
"""

print(sort_headers(text))
# accept: application/json, text/plain
# Host: example.com
# X-Trace-Id: abc123

print(sort_headers(text, downcase=True))
# accept: application/json, text/plain
# host: example.com
# x-trace-id: abc123
```

`sort_headers(text)` returns one `Name: value` line per header, ordered
case-insensitively by name. Ordering never depends on case, and equal names
keep the order they were pasted in:

```python
sort_headers("banana: 1\nApple: 2\ncarrot: 3\napple: 4")
# Apple: 2
# apple: 4
# banana: 1
# carrot: 3
```

`Apple` sorts next to `apple` because `A` and `a` compare equal, and the two
keep their pasted order because sorting is stable. `downcase=True` changes only
how the names print, never the order.

`downcase=True` lowercases every field name in the output (`Host` → `host`).
Field values are never changed, because values may be case-sensitive
(`Authorization: Bearer AbC123` keeps its case). Sorting is case-insensitive
already, so this only affects how names are emitted, not their order.

Parsing is deliberately forgiving about formatting and strict about
structure:

- blank lines and surrounding whitespace are dropped;
- `Name:value`, `Name:   value` and `Name:\tvalue` all normalise to
  `Name: value`;
- folded (continuation) lines starting with a space or tab are joined onto
  the header above them;
- `\n`, `\r\n` and `\r` line endings are accepted;
- a line without a colon, an empty name, an invalid name token, or an
  orphaned continuation line raises `InvalidHeaderError` (a `ValueError`)
  naming the offending line.

Use `parse_headers(text)` when you want the pairs without re-formatting;
it returns a tuple of `Header(name, value)`. It accepts the same
`downcase=True` keyword.
