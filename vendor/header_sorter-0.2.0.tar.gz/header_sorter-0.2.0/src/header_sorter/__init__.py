"""Clean up pasted request headers by ordering them alphabetically.

    >>> from header_sorter import sort_headers
    >>> print(sort_headers("host: example.com\\nAccept: */*"))
    Accept: */*
    host: example.com
"""

from .core import (
    Header,
    InvalidHeaderError,
    canonical_name,
    canonical_value,
    check_header,
    parse_headers,
    sort_headers,
)

__all__ = [
    "Header",
    "InvalidHeaderError",
    "canonical_name",
    "canonical_value",
    "check_header",
    "parse_headers",
    "sort_headers",
]
__version__ = "0.2.0"
