"""Read pasted HTTP headers and return them in alphabetical order."""

from __future__ import annotations

import re
from typing import NamedTuple

__all__ = [
    "Header",
    "InvalidHeaderError",
    "canonical_name",
    "canonical_value",
    "check_header",
    "parse_headers",
    "sort_headers",
]

# RFC 9110 tchar: everything allowed in a header field name.
_NAME_RE = re.compile(r"^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$")

# Optional whitespace, as HTTP defines it (SP and HTAB only).
_OWS = " \t"


class InvalidHeaderError(ValueError):
    """Raised when the text cannot be read as a list of HTTP headers.

    ``code`` and ``location`` are optional structured attributes for callers
    that need to map the failure onto their own error model. The message text
    is unchanged from earlier releases.
    """

    def __init__(
        self,
        message: str,
        *,
        code: str = "header.syntax",
        location: str = "",
    ) -> None:
        super().__init__(message)
        self.code = code
        self.location = location


class Header(NamedTuple):
    """A single ``Name: value`` header pair, with whitespace normalised."""

    name: str
    value: str

    def __str__(self) -> str:
        return f"{self.name}: {self.value}"


def canonical_name(name: str) -> str:
    """Return the lowercased field name, or raise ``InvalidHeaderError``.

    A canonical name is 1..n characters, each from the RFC 9110 tchar set
    (``!#$%&'*+-.^_`|~``, digits, letters). No whitespace, no colon, no
    control characters, ASCII only. Lowercased.
    """
    if not isinstance(name, str):
        raise InvalidHeaderError(
            f"header name must be a string; got {type(name).__name__}",
            code="header.name-invalid",
        )
    if not _NAME_RE.fullmatch(name):
        raise InvalidHeaderError(
            f"{name!r} is not a valid header name",
            code="header.name-invalid",
        )
    return name.lower()


def canonical_value(value: str) -> str:
    """Return the field value in canonical form, or raise ``InvalidHeaderError``.

    Canonical form: leading and trailing optional whitespace (SP and HTAB)
    removed; internal whitespace preserved byte for byte; empty string
    allowed; any C0 control character other than HTAB rejected; DEL (0x7F)
    rejected; non-ASCII allowed (callers encode UTF-8).
    """
    if not isinstance(value, str):
        raise InvalidHeaderError(
            f"header value must be a string; got {type(value).__name__}",
            code="header.value-type",
        )
    for character in value:
        code_point = ord(character)
        if code_point == 0x7F or (code_point < 0x20 and character != "\t"):
            raise InvalidHeaderError(
                f"header value contains a control character: {value!r}",
                code="header.value-control-char",
            )
    return value.strip(_OWS)


def check_header(name: str, value: str) -> Header:
    """Canonicalise a name and value, returning them as a ``Header``."""
    return Header(canonical_name(name), canonical_value(value))


def parse_headers(
    text: str,
    *,
    downcase: bool = False,
    strict: bool = False,
) -> tuple[Header, ...]:
    """Parse multi-line header text into ``Header`` pairs, keeping order.

    Blank lines are ignored, ``Name:value`` is normalised to ``Name: value``,
    and folded continuation lines are joined onto the header above them.
    Line endings may be ``\\n``, ``\\r\\n`` or ``\\r``.

    With ``downcase`` the field names are lowercased; values are left exactly
    as they were, since field values can be case-sensitive.

    With ``strict`` every value must also survive :func:`canonical_value`, so
    a control character in a value raises ``InvalidHeaderError``. Leading and
    trailing optional whitespace is still trimmed silently, exactly as it is
    without ``strict``; this function has no channel for reporting repairs.
    """
    if not isinstance(text, str):
        raise InvalidHeaderError(
            f"headers must be a string; got {type(text).__name__}"
        )

    headers: list[Header] = []
    for number, raw in enumerate(text.replace("\r\n", "\n").replace("\r", "\n").split("\n"), 1):
        line = raw.strip()
        if not line:
            continue

        if raw[0] in " \t":
            name, sep, _ = line.partition(":")
            if not (sep and _NAME_RE.match(name.strip())):
                # obs-fold: the line continues the value of the header above.
                if not headers:
                    raise InvalidHeaderError(
                        f"line {number}: continuation line without a preceding header"
                    )
                previous = headers[-1]
                joined = f"{previous.value} {line}"
                headers[-1] = Header(
                    previous.name, canonical_value(joined) if strict else joined
                )
                continue
            # Otherwise it is an indented header, e.g. a pasted code block.

        name, sep, value = line.partition(":")
        if not sep:
            raise InvalidHeaderError(
                f"line {number}: expected 'Name: value', got {line!r}"
            )
        name = name.strip()
        if not name:
            raise InvalidHeaderError(f"line {number}: header name is empty")
        if not _NAME_RE.match(name):
            raise InvalidHeaderError(
                f"line {number}: {name!r} is not a valid header name"
            )
        normalised = canonical_value(value) if strict else value.strip()
        headers.append(Header(name.lower() if downcase else name, normalised))

    if not headers:
        raise InvalidHeaderError("no headers found in the input")
    return tuple(headers)


def sort_headers(text: str, *, downcase: bool = False) -> str:
    """Return ``text`` re-emitted with one header per line, sorted by name.

    Sorting is case-insensitive and stable, so repeated field names keep
    their original relative order. Pass ``downcase=True`` to emit every field
    name in lowercase; values keep their original case either way.
    """
    headers = sorted(
        parse_headers(text, downcase=downcase), key=lambda h: h.name.lower()
    )
    return "\n".join(str(header) for header in headers)
